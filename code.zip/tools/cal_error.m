function [errors]=cal_error(x_all,y_all)

[new_x,~]=mapminmax(x_all');
new_x=new_x';
[new_y,~]=mapminmax(y_all');
new_y=new_y';
model = svmtrain(new_y,new_x,'-s 3 -t 2 -p 0.000001');
[py1,~,~] = svmpredict(new_y,new_x,model);
errors=new_y-py1;
end

