function rho=cal_rou(data,isKernal,delta)
data=normalize(data);
ND = max(data(:,2));
NL = max(data(:,1));
if (NL>ND)
    ND = NL;   
end 
 N = size(data,1);
 for i = 1:ND
   for j = 1:ND
     dist(i,j) = 0;
     c(i,j) = 0;
   end
 end

for i = 1:N-1
    ix = data(i,1);
    iy = data(i,2);
    for  j=i+1:N
        jx = data(j,1);
        jy = data(j,2);
        if isKernal == true
            dist(i,j) = kernal(ix,iy,ix,iy,delta)-2*kernal(ix,iy,jx,jy,delta)+ kernal(jx,jy,jx,jy,delta);
            dist(j,i) = dist(i,j);
        else
            c(i,j) = sqrt((ix-jx)^2+(iy-jy)^2);
            c(j,i) = sqrt((ix-jx)^2+(iy-jy)^2);
        end
    end
end

for i = 1:N
    if isKernal == true
        dist(i,i) = 0;
    else
        c(i,i) = 0;
    end 
end
if isKernal == true
    N = size(dist, 1) * (size(dist, 2) - 1) / 2;
    ND = size(dist, 1);
else
    N = size(c, 1) * (size(c, 2) - 1) / 2;
    ND = size(c, 1);
end
percent = 2;
position = round(N*percent/100);  
if isKernal == true
    sda = sort(squareform(dist));
    dc = sda(position);
else
    sda = sort(squareform(c));
    dc = sda(position);

end
rho = [];
for i = 1:ND
    rho(i) = 0.;
end

for i = 1:ND-1
    for j = i+1:ND
        if isKernal == true
            rho(i) = rho(i)+exp(-(dist(i,j)/dc)*(dist(i,j)/dc));
            rho(j) = rho(j)+exp(-(dist(j,i)/dc)*(dist(j,i)/dc));
        else 
            rho(i) = rho(i)+exp(-(c(i,j)/dc)*(c(i,j)/dc));
            rho(j) = rho(j)+exp(-(c(j,i)/dc)*(c(j,i)/dc));
        end
    end
end
rho=rho';
end
