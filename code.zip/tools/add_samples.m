function [tabu_list,farthestPoint]=add_samples(k,x_all,randomPoints,tabu_list)
    %获取维度
%     n=size(x_all,2);
    indices = ismember(x_all, x_all(k,:),'rows');

% 删除指定数值的点
    knownPoints = x_all;
    knownPoints(indices,:) = [];
    centerIndex=k;
    centerPoint=x_all(centerIndex,:);
    numRandomPoints=size(randomPoints,1);
%     randomPoint = repmat(centerPoint, numRandomPoints, 1) + radius .* randn(numRandomPoints, n);
%     indices = any(randomPoint < ub | randomPoint > lb, 2);
% 
% % 删除不在区间范围内的点
%     randomPoints = randomPoint(~indices, :);


%     randomPoint = zeros(numRandomPoints, length(centerPoint));
%     for i = 1:numRandomPoints
%         for j = 1:length(centerPoint)
%             randomPoint(i,j) = centerPoint(j) + (rand-0.5)*2*radius(j);
%         end
%     end
%     randomPoint = bsxfun(@plus, centerPoint, diag(radius) * randn(length(centerPoint), numRandomPoints));
%     indices = any(randomPoint < ub | randomPoint > lb, 2);
% 
% % 删除不在区间范围内的点
%     randomPoints = randomPoint(~indices, :);



   
    distancesToCenter = vecnorm(randomPoints - centerPoint, 2, 2);

% 初始化一个逻辑向量，用于判断随机点是否离指定点更近
    isCloserToCenter = false(numRandomPoints, 1);

for i = 1:size(randomPoints,1)
    % 获取当前随机点
    currentPoint = randomPoints(i, :);
    
    % 计算当前随机点到所有已知点的欧氏距离
    distancesToKnownPoints = vecnorm(currentPoint - knownPoints, 2, 2);
    
    % 判断当前随机点是否离指定点更近
    if min(distancesToKnownPoints) > distancesToCenter(i)
        isCloserToCenter(i) = true;
    end
end

% 获取离指定点距离更近的随机点的坐标
closerPoints = randomPoints(isCloserToCenter, :);

% 计算离指定点最远的点的索引
[~, farthestIndex] = max(distancesToCenter(isCloserToCenter));
% 计算离所有已知点最远的点的索引
% 获取离指定点最远的点的坐标
farthestPoint = closerPoints(farthestIndex, :);
% maxDistance = -inf;
% 
% for i=1:size(closerPoints,1)
%     distance = norm(closerPoints(i,:)-centerPoint);
%     if distance > maxDistance
%           farthestPoint = closerPoints(i,:);
%           maxDistance = distance;
%      end
%  end
% if isempty(farthestPoint)
%     tabu_list=[tabu_list;k];
% end

if isempty(farthestPoint)
%     tabu_list=[tabu_list;k];
    distances = sqrt(sum((knownPoints - centerPoint).^2, 2));

% 找到最小距离的随机点的索引
    [minDistance, minIndex] = min(distances);

% 最近距离随机点的坐标
    nearestPoint = knownPoints(minIndex, :);

% 计算指定点与最近距离随机点的中点
    farthestPoint = (centerPoint + nearestPoint) / 2;
end

end
