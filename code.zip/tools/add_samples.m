function [farthestPoint]=add_samples(k,x_all,randomPoints)
    indices = ismember(x_all, x_all(k,:),'rows');
    knownPoints = x_all;
    knownPoints(indices,:) = [];
    centerIndex=k;
    centerPoint=x_all(centerIndex,:);
    numRandomPoints=size(randomPoints,1);   
    distancesToCenter = vecnorm(randomPoints - centerPoint, 2, 2);
    isCloserToCenter = false(numRandomPoints, 1);

for i = 1:size(randomPoints,1)
    currentPoint = randomPoints(i, :);
    distancesToKnownPoints = vecnorm(currentPoint - knownPoints, 2, 2);
    if min(distancesToKnownPoints) > distancesToCenter(i)
        isCloserToCenter(i) = true;
    end
end

closerPoints = randomPoints(isCloserToCenter, :);

[~, farthestIndex] = max(distancesToCenter(isCloserToCenter));
farthestPoint = closerPoints(farthestIndex, :);

end
