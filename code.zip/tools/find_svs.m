function [allsvs,coefs]=find_svs(x,y,p_value)
[new_x,settings1]=mapminmax(x');
new_x=new_x';
[new_y,settings2]=mapminmax(y',0,1);
new_y=new_y';
params = ['-s 3 -t 2 -p ', num2str(p_value)];
model = svmtrain(new_y, new_x, params);
svs=full(model.SVs);
coefs=model.sv_coef;
allsvs=x(ismember(new_x,svs,'rows'),:);
end

