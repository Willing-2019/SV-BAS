clear all; clc; close all
ub= [-2,-1];
lb=[2,1];
add_num=10;
stepsize=15;
[x]=lhsdesign(5*size(ub,2),size(ub,2)).*(lb-ub)+ub;
tic
x_all=x;
d=size(x,2);
y=SHCamel_2d(x);
y_all=y;
errors=[];
p_value = 0.1;
ps=[];
yns=[];
for m=1:stepsize
    numRandomPoints=size(x_all,1)*200;
    randomPoints=lb + (ub - lb) .* rand(numRandomPoints, size(x_all,2));
    [svs,coefs]=find_svs(x_all,y_all,p_value);
    rou=cal_rou(x_all,false,delta);
    svs=unique(svs,'rows');
    flag1=ismember(x_all, svs,'rows');
    [deltay]=cal_error(x_all,y_all);
    if sum(flag1)/size(x_all,1)<0.15
        p_value=p_value-0.05;
    end
    p_value=max(p_value,0.05);
    [k,new_rous,new_coefs]=choose_vor(rou,coefs,deltay,add_num,flag1);
    for i =1:length(k)
        [x_new]=add_samples(k(i),x_all,randomPoints);
        x_all=[x_all;x_new];
    end
    y_all=[SHCamel_2d(x_all)];
    %     error=test_error(x_all, y_all);
    %     errors=[errors;error];
end
